// Copyright (c) 2026 WebCpp.org
//
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// https://www.boost.org/LICENSE_1_0.txt)

/**
 The selected Asio umbrella and WebCPP extensions, excluding optional TLS headers.
*/
#ifndef WEBCPP_ASIO_HPP
#define WEBCPP_ASIO_HPP

#include <webcpp/asio/config.hpp>

#ifdef WEBCPP_TARGET_NATIVE
#include <boost/asio.hpp>
#else
#include <webcpp/asio/detail/backend.hpp>
#endif

#include <webcpp/asio/basic_datagram_socket.hpp>
#include <webcpp/asio/basic_socket_acceptor.hpp>
#include <webcpp/asio/basic_stream_socket.hpp>
#include <webcpp/asio/basic_waitable_timer.hpp>
#include <webcpp/asio/io_context.hpp>
#include <webcpp/asio/ip/basic_resolver.hpp>
#include <webcpp/asio/ip/tcp.hpp>
#include <webcpp/asio/ip/udp.hpp>
#include <webcpp/asio/steady_timer.hpp>  // lint-world: Boost's timers are asio's
#include <webcpp/asio/system_timer.hpp>  // lint-world: Boost's timers are asio's

#ifdef WEBCPP_TARGET_EMSCRIPTEN
#include <webcpp/asio/browser/async_await.hpp>
#include <webcpp/asio/browser/async_wait_event.hpp>
#include <webcpp/asio/browser/bridge.hpp>
#include <webcpp/asio/browser/error.hpp>
#if WEBCPP_ASIO_HAS_BROWSER_WORKERS
#include <webcpp/asio/browser/main_thread_context.hpp>
#endif
#endif

#endif  // WEBCPP_ASIO_HPP
