#!/usr/bin/env python3
"""Run local conformance lanes and retain commands, logs and source identities."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shlex
import signal
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def identity():
    files = {}
    for library in ('asio', 'cobalt', 'beast', 'config'):
        base = ROOT / 'libs' / library
        paths = [base / 'build.jam']
        for directory in ('include', 'src', 'test', 'example'):
            paths += list((base / directory).rglob('*'))
        for path in sorted(paths):
            if path.is_file() and not any(p in ('node_modules', '__pycache__', 'results')
                                          for p in path.parts):
                if path.suffix in ('.cpp', '.hpp', '.h', '.ipp', '.inl', '.inc', '.tcc', '.c', '.cc', '.cxx', '.jam', '.py', '.mjs', '.js', '.html', '.json', '.expected') \
                        or path.name == 'Jamfile':
                    files[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return files


def cobalt_jobs():
    portable = 'libs/cobalt/test/applications//'
    for target in ('native', 'wasip2', 'wasip3', 'jspi', 'asyncify'):
        for threads in ('single', 'multi'):
            for eh in ('on', 'off'):
                if target == 'wasip2' and threads == 'multi':
                    continue
                if target == 'wasip3' and threads == 'multi' and eh == 'on':
                    continue
                browser = target in ('jspi', 'asyncify')
                props = [f'threading={threads}', f'exception-handling={eh}']
                if target != 'native':
                    props += ['toolset=' + ('emscripten' if browser else 'clang-' + target)]
                if target in ('wasip2', 'wasip3'):
                    props += ['testing.launcher=' + str(ROOT / f'tools/boost/asio-{target}/run.sh')]
                if browser:
                    props += ['webcpp-suspend=' + target]
                if target == 'native' and eh == 'off':
                    props += ['cxxflags=-Wno-error=coroutine-missing-unhandled-exception']
                lane = 'upstream-portable' if target == 'native' else \
                    'migrated-portable-p3' if target == 'wasip3' else 'migrated-portable'
                counterpart = 'portable-counterparts-p3' if target == 'wasip3' else 'portable-counterparts'
                targets = [portable + lane, 'libs/cobalt/test/applications/portable//' + counterpart,
                           'libs/cobalt/example//asio_cobalt.output',
                           'libs/asio/example//asio_quick_start.output',
                           'libs/asio/example//asio_timers.output']
                if target == 'native' and eh == 'on':
                    targets += [portable + 'upstream-workers']
                if threads == 'multi':
                    targets += ['libs/cobalt/test/applications/spsc//spsc-wakeup',
                                'libs/cobalt/test/applications/spsc//spsc-sequence']
                if browser:
                    targets += ['libs/cobalt/test/browser//browser-pages']
                    if target == 'jspi':
                        # This lane builds and executes both suspension variants.
                        targets += ['libs/cobalt/test/browser//browser-network-counterparts']
                    if threads == 'multi':
                        targets += ['libs/cobalt/test/browser//browser-workers',
                                    'libs/cobalt/test/browser//browser-worker-pages',
                                    'libs/cobalt/test/browser//browser-runtime-probes']
                        if eh == 'on':
                            targets += [portable + 'migrated-worker-modules']
                elif eh == 'on':
                    network = 'libs/cobalt/test/applications/network//'
                    targets += [network + ('controlled-oracle' if target == 'native' else 'controlled-port')]
                    targets += [network + ('original_' if target == 'native' else 'migrated_') + name
                                for name in ('http', 'ticker')]
                yield f'cobalt-{target}-{threads}-{eh}', props, targets


def beast_jobs():
    base = 'libs/beast/test/applications/'
    groups = {
        'p2': ['wasip3//applications-p2'],
        'p3': ['wasip3//applications-p3'],
        'native-single': ['noexcept//applications-single'],
        'native-noeh': ['noexcept//applications-noexcept', 'noexcept//applications-single-noexcept'],
        'p2-noeh': ['noexcept//applications-single-noexcept'],
        'p3-noeh': ['noexcept//applications-single-noexcept'],
        'p3-cooperative-noeh': ['noexcept//applications-cooperative-noexcept'],
    }
    for abi in ('p2', 'p3'):
        for eh in ('on', 'off'):
            groups[f'{abi}-host-{eh}'] = [d + '//' + lane for d, lane in (
                ('host', 'applications-host'), ('host-clients', 'applications-host-clients'),
                ('host-extra', 'applications-host-extra'), ('host-tls', 'applications-host-tls'),
                ('streams', 'applications-streams'), ('streams', 'applications-websocket-streams'))]
    for name, lanes in groups.items():
        props = []
        if name.startswith(('p2', 'p3')):
            props += ['toolset=clang-wasi' + name[:2]]
        if name.endswith(('noeh', '-off')):
            props += ['exception-handling=off']
        yield 'beast-' + name, props, [base + lane for lane in lanes]
    # Each application lane builds and drives JSPI and Asyncify itself.
    for variant in ('jspi',):
        for eh in ('on', 'off'):
            for threads in ('single', 'multi'):
                directory = 'browser' if eh == 'on' else 'browser-noexcept'
                yield f'beast-browser-{variant}-{threads}-{eh}', \
                    ['toolset=emscripten', 'webcpp-suspend=' + variant,
                     'exception-handling=' + eh, 'threading=' + threads], \
                    [base + directory + '//applications-browser']


def asio_jobs():
    for name, props, _ in cobalt_jobs():
        props = [value for value in props if not value.startswith('cxxflags=-Wno-error=')]
        target = name.split('-')[1]
        browser = target in ('jspi', 'asyncify')
        examples = ['asio_quick_start', 'asio_timers']
        examples += (['asio_turn_limit', 'asio_promise', 'asio_event', 'asio_sockets',
                      'asio_resolver'] if browser else ['asio_tls_client', 'asio_capabilities'])
        yield name.replace('cobalt-', 'asio-', 1), props, [
            'libs/asio/example//' + example + '.output' for example in examples]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('group', choices=('asio', 'cobalt', 'beast'))
    parser.add_argument('--only', nargs='*')
    args = parser.parse_args()
    out = HERE / 'matrix'
    out.mkdir(exist_ok=True)
    env = dict(os.environ)
    for name in ('CPATH', 'CPLUS_INCLUDE_PATH', 'C_INCLUDE_PATH'):
        env.pop(name, None)
    env['PATH'] = str(ROOT / '.local/wasmtime-50/wasmtime') + ':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
    env['WASMTIME'] = str(ROOT / '.local/wasmtime-50/wasmtime/wasmtime')
    env['WEBCPP_WASI_TLS_FIXTURE'] = str(ROOT / '.local/beast-completion/host-tls-target/debug/webcpp-beast-host-tls-fixture')
    env['EMSDK_PYTHON'] = '/opt/homebrew/bin/python3'
    env['EM_CACHE'] = str(ROOT / '.local/emscripten-cache')
    failures = []
    jobs = {'asio': asio_jobs, 'cobalt': cobalt_jobs, 'beast': beast_jobs}[args.group]()
    for name, props, targets in jobs:
        if args.only and name not in args.only:
            continue
        sources = identity()
        digest = hashlib.sha256(json.dumps(sources, sort_keys=True).encode()).hexdigest()
        (out / (digest + '.sources.json')).write_text(json.dumps(sources, indent=2) + '\n')
        command = ['b2', '--user-config=.local/user-config.jam', '-a', '-d2', '-j3',
                   'variant=release', *props, *targets]
        record = {'id': name, 'command': command, 'source_manifest': digest + '.sources.json',
                  'platform': platform.platform(), 'started': time.time()}
        print('RUN ' + name + ': ' + shlex.join(command), flush=True)
        log = out / (name + '.log')
        env['WEBCPP_BROWSER_EVIDENCE'] = str(out / name)
        with log.open('w') as stream:
            stream.write(shlex.join(command) + '\n')
            stream.flush()
            process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=stream,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            try:
                code = process.wait(timeout=3600)
            except BaseException:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=10)
                raise
        record.update(status=code, seconds=time.time() - record['started'],
                      log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
                      passed=re.findall(r'\*\*passed\*\* (\S+)', log.read_text()),
                      failed=re.findall(r'\*\*failed\*\* (\S+)', log.read_text()))
        (out / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
        print(f'END {name}: exit={code}, passes={len(record["passed"])}, seconds={record["seconds"]:.1f}', flush=True)
        if code:
            failures.append(name)
    print('FAILED JOBS: ' + json.dumps(failures), flush=True)
    return bool(failures)


if __name__ == '__main__':
    raise SystemExit(main())
