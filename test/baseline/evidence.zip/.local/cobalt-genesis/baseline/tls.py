from pathlib import Path
import json
import os
import shlex
import subprocess
import time

root = Path.cwd()
output = root / '.local/cobalt-genesis/baseline'
env = dict(os.environ)
for key in ('CPATH', 'CPLUS_INCLUDE_PATH', 'C_INCLUDE_PATH'):
    env.pop(key, None)
env['PATH'] = str(root / '.local/wasmtime-50/wasmtime') + ':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
env['WASMTIME'] = str(root / '.local/wasmtime-50/wasmtime/wasmtime')
env['USER_CONFIG'] = str(root / '.local/user-config.jam')
base = ['b2', '-a', '-j4', '--user-config=.local/user-config.jam', 'variant=release']
records = []

def run(name, command):
    print('START ' + name + ': ' + shlex.join(command), flush=True)
    start = time.monotonic()
    with (output / (name + '.log')).open('w') as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
    records.append(dict(name=name, command=command, exit=result.returncode,
                        elapsed_seconds=time.monotonic()-start))
    (output / 'tls-runs.json').write_text(json.dumps(records, indent=2) + '\n')
    print('END ' + name + ': ' + str(result.returncode), flush=True)
    if result.returncode:
        print((output / (name + '.log')).read_text()[-5000:], flush=True)
        raise SystemExit(result.returncode)

run('wasip2-tls', base + ['toolset=clang-wasip2',
    'testing.launcher=wasmtime run -S inherit-network=y -S allow-ip-name-lookup=y',
    '--dump-tests', '--out-xml=' + str(output / 'wasip2-tls.xml'),
    'libs/asio/test/wasip2_tls_cobalt//wasip2-tls'])
run('wasip2-tls-verdict', ['python3','tools/report/report.py','--lane',
    'wasip2=' + str(output / 'wasip2-tls.xml'),'--out',str(output / 'wasip2-tls-report')])
for profile, toolset, suffix in [('native', [], ''), ('wasip3', ['toolset=clang-wasip3'], '.wasm')]:
    names = ['cobalt_ssl_client', 'cobalt_ssl_state', 'cobalt_ssl_cancel']
    run(profile + '-tls-build', base + toolset + ['tools/openssl/test//' + name for name in names])
    pattern = 'clang-darwin-21' if profile == 'native' else 'clang-darwin-wasip3'
    for name in names:
        candidates = [p for p in (root / 'bin/tools/openssl/test').rglob(name + suffix)
                      if pattern in p.parts and 'release' in p.parts
                      and 'threading-multi' not in p.parts and 'exception-handling-off' not in p.parts]
        if len(candidates) != 1:
            raise RuntimeError((name, candidates))
        args = ['--embedded','--require-sni'] if name == 'cobalt_ssl_client' else ['--state-test']
        run(profile + '-' + name, ['python3', 'tools/openssl/test/tls.py', str(candidates[0]), *args])
