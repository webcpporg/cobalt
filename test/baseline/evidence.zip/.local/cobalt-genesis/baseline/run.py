from pathlib import Path
import json
import os
import shlex
import subprocess
import time

root = Path.cwd()
output = root / '.local/cobalt-genesis/baseline'
env = dict(os.environ)
for key in ('CPATH', 'CPLUS_INCLUDE_PATH', 'C_INCLUDE_PATH'):
    env.pop(key, None)
env['PATH'] = str(root / '.local/wasmtime-50/wasmtime') + '/:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
env['WASMTIME'] = str(root / '.local/wasmtime-50/wasmtime/wasmtime')
base = ['b2', '-a', '-j4', '--user-config=.local/user-config.jam', 'variant=release',
        '--dump-tests']
requests = [
    ('emscripten-jspi', ['toolset=emscripten', 'libs/asio/test//cobalt',
        'libs/asio/test//cobalt_exceptions_on', 'libs/asio/test//cobalt_exceptions_off',
        'libs/asio/example//asio_cobalt.output']),
    ('emscripten-asyncify', ['toolset=emscripten', 'libs/asio/test//cobalt_asyncify',
        'libs/asio/test//cobalt_exceptions_on_asyncify',
        'libs/asio/test//cobalt_exceptions_off_asyncify']),
    ('wasip2', ['toolset=clang-wasip2',
        'testing.launcher=wasmtime run -S inherit-network=y -S allow-ip-name-lookup=y',
        'libs/asio/test/wasip2_tls_cobalt']),
    ('wasip3', ['toolset=clang-wasip3',
        'testing.launcher=tools/boost/asio-wasip3/run.sh',
        'libs/asio/test//cobalt_wasi', 'libs/asio/test//cobalt_network_wasi',
        'libs/asio/test//cobalt_io', 'libs/asio/test//cobalt_accept_cancel',
        'libs/asio/test//cobalt_wasip3']),
    ('wasip3-threads', ['toolset=clang-wasip3', 'threading=multi',
        'exception-handling=off', 'testing.launcher=tools/boost/asio-wasip3/run.sh',
        'libs/asio/test//cobalt_thread']),
    ('native-threads', ['threading=multi', 'exception-handling=off',
        'libs/asio/test//cobalt_thread']),
]
records = []
for name, arguments in requests:
    if name.startswith('emscripten'):
        continue
    xml = output / (name + '.xml')
    command = base + ['--out-xml=' + str(xml)] + arguments
    print('START ' + name + ': ' + shlex.join(command), flush=True)
    start = time.monotonic()
    with (output / (name + '.log')).open('w') as log:
        result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT,
                                timeout=1800)
    target = ('emscripten' if name.startswith('emscripten') else
              'wasip3' if name.startswith('wasip3') else
              'wasip2' if name == 'wasip2' else 'native')
    report_command = ['python3', 'tools/report/report.py', '--lane', target + '=' + str(xml),
                      '--out', str(output / (name + '-report'))]
    report = subprocess.run(report_command, env=env, capture_output=True, text=True,
                            timeout=60)
    (output / (name + '-verdict.log')).write_text(report.stdout + report.stderr)
    record = dict(profile=name, command=command, exit=result.returncode,
                  report_exit=report.returncode, elapsed_seconds=time.monotonic() - start,
                  result_artifact=str(xml.relative_to(root)))
    records.append(record)
    (output / 'runs.json').write_text(json.dumps(records, indent=2) + '\n')
    print('END ' + name + ': ' + json.dumps(record), flush=True)
    if result.returncode or report.returncode:
        print((output / (name + '.log')).read_text()[-4000:], flush=True)
        print(report.stdout + report.stderr, flush=True)
        raise SystemExit(1)
